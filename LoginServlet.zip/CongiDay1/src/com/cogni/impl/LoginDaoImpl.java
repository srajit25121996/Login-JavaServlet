package com.cogni.impl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cogni.dao.Logindao;
import com.cogni.util.JdbcConnection;

public class LoginDaoImpl  implements Logindao{


	public boolean validateLogin(String user, String password) {
		// TODO Auto-generated method stub
		
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		con=JdbcConnection.getConnection();
		
		String query="select * from Login where username=? and password=?";
		try {
			pst=con.prepareStatement(query);
			pst.setString(1, user);
			pst.setString(2, password);
			rs=pst.executeQuery();
			if(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			if(rs != null){
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (pst != null){
				try {
					pst.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
if(con != null){
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} 
		
		
		return false;
	}
	

}
