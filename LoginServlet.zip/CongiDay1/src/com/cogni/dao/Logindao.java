package com.cogni.dao;

public interface Logindao {
boolean validateLogin(String user, String password);
}
